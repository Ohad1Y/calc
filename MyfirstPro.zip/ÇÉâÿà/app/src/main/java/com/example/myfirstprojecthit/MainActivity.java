package com.example.myfirstprojecthit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView result;
    int Num1=0;
    int Num2=0;
    int status = 0;
    int operator = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       result =findViewById(R.id.textViewResult);

    }

    public void restart(){
        int Num1=0;
        int Num2=0;
        int status = 0;
        int operator = 0;
        result.setText("");
    }
    public void changeMode(){
        if (status==0){
            Num1= Integer.valueOf(result.getText().toString());
            status=0;
            result.setText("");
        }

    }

    public void buttonFunctionclear(View view) {
        restart();
    }

    public void buttonFunctionEq(View view) {
        if (status==1)
            Num2 = Integer.valueOf(result.getText().toString());
            if (operator==1){
                result.setText(String.valueOf(Num1+Num2));
            }
        if (operator==2){
            result.setText(String.valueOf(Num1-Num2));
        }
        if (operator==3){
            result.setText(String.valueOf(Num1*Num2));
        }
        status = 3;

    }
    public void buttonFunctionNumber(View view) {
        if (view instanceof Button) {
            Button b =  (Button) view;

            String str = b.getText().toString();
            //result.append(str);
            if (status==3){
               restart();
            }
            if (result.getText().toString().startsWith("0"){
                result.setText(str);

            }

        }
    }


    public void buttonFunctionAction(View view) {
        if (view instanceof Button) {
            Button b =  (Button) view;

            String str = b.getText().toString();
            //result.append(str);
            if (str.equals("x")){
                status = 1;
                changeMode();
            }
            else if (str.equals("+")){
                status=2;
                changeMode();
            }
            else if (str.equals("-")){
                status=3;
                changeMode();

            }

        }
        }

    }
